'use client';

import { useState, useRef, useEffect } from 'react';
import { Bot, X, Send } from 'lucide-react';

type Message = {
  id: number;
  role: 'user' | 'bot';
  text: string;
};

const WELCOME_TEXT = 'Welcome to Karma Ayurveda! Feel free to chat with me for your concerns.';
const INITIAL_DELAY = 3000;
const VISIBLE_DURATION = 7000;
const HIDDEN_DURATION = 5000;

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [chatClosing, setChatClosing] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: 'bot',
      text: "Hi there! How can I help you today?",
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Welcome popup state
  const [popupVisible, setPopupVisible] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Welcome popup loop — pauses while the chatbox is open or closing
  useEffect(() => {
    if (open || chatClosing) {
      setPopupVisible(false);
      return;
    }

    const startLoop = () => {
      setPopupVisible(true);
      timerRef.current = setTimeout(() => {
        setPopupVisible(false);
        timerRef.current = setTimeout(startLoop, HIDDEN_DURATION);
      }, VISIBLE_DURATION);
    };

    timerRef.current = setTimeout(startLoop, INITIAL_DELAY);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [open, chatClosing]);

  const handlePopupClose = () => {
    setPopupVisible(false);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(function loop() {
      setPopupVisible(true);
      timerRef.current = setTimeout(() => {
        setPopupVisible(false);
        timerRef.current = setTimeout(loop, HIDDEN_DURATION);
      }, VISIBLE_DURATION);
    }, HIDDEN_DURATION);
  };

  const sendMessage = () => {
    const text = input.trim();
    if (!text) return;

    const userMessage: Message = {
      id: Date.now(),
      role: 'user',
      text,
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Placeholder bot reply — wire this to your API
    setTimeout(() => {
      const botMessage: Message = {
        id: Date.now() + 1,
        role: 'bot',
        text: "Thanks for your message! This is a demo response — connect your API to make me smart.",
      };
      setMessages((prev) => [...prev, botMessage]);
      setIsTyping(false);
    }, 1200);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-[2147483647] flex flex-col items-end gap-3">
      {/* Welcome popup — grows from the chatbot icon */}
      <div
        className={`pointer-events-auto origin-bottom-right transition-all duration-300 ease-out ${
          popupVisible
            ? 'scale-100 opacity-100'
            : 'scale-0 opacity-0'
        }`}
        style={{ transformOrigin: 'bottom right' }}
      >
        <div className="relative max-w-[16rem] rounded-2xl rounded-br-sm border border-border bg-card px-4 py-3 shadow-xl sm:max-w-[20rem]">
          <button
            onClick={handlePopupClose}
            className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full border border-border bg-background shadow-md transition-colors hover:bg-secondary"
            aria-label="Dismiss"
          >
            <X className="h-3 w-3" />
          </button>
          <p className="pr-3 text-sm leading-relaxed text-foreground">
            {WELCOME_TEXT}
          </p>
        </div>
      </div>

      {/* Chat window */}
      {(open || chatClosing) && (
        <div
          className={`flex w-80 flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl sm:w-96 ${
            open && !chatClosing ? 'chat-pop-in' : 'chat-pop-out'
          }`
          }
          onAnimationEnd={() => {
            if (chatClosing) setChatClosing(false);
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-border bg-primary px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground">
                <Bot className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-primary-foreground">Chat Assistant</p>
                <p className="text-xs text-primary-foreground/70">Typically replies instantly</p>
              </div>
            </div>
            <button
              onClick={() => {
                setChatClosing(true);
                setOpen(false);
              }}
              className="rounded-full p-1.5 transition-colors hover:bg-primary-foreground/10"
              aria-label="Close chat"
            >
              <X className="h-5 w-5 text-primary-foreground" />
            </button>
          </div>

          {/* Messages */}
          <div
            ref={scrollRef}
            className="flex h-80 flex-col gap-3 overflow-y-auto bg-secondary/30 p-4"
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'rounded-br-sm bg-primary text-primary-foreground'
                      : 'rounded-bl-sm bg-muted text-muted-foreground'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-center gap-1 rounded-2xl rounded-bl-sm bg-muted px-4 py-3">
                  <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.3s]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60 [animation-delay:-0.15s]" />
                  <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/60" />
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="flex items-center gap-2 border-t border-border bg-card p-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              className="h-10 flex-1 rounded-full border border-input bg-background px-4 text-sm outline-none transition-colors focus:border-ring focus:ring-1 focus:ring-ring"
            />
            <button
              onClick={sendMessage}
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50"
              aria-label="Send message"
              disabled={!input.trim()}
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Toggle button */}
      <button
        onClick={() => {
          if (open) {
            setChatClosing(true);
            setOpen(false);
          } else {
            setOpen(true);
          }
        }}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 to-blue-700 text-white shadow-xl transition-all duration-200 hover:scale-105 active:scale-95"
        aria-label={open ? 'Close chat' : 'Open chat'}
      >
        {open ? (
          <X className="h-6 w-6" />
        ) : (
          <Bot className="h-6 w-6" />
        )}
      </button>
    </div>
  );
}